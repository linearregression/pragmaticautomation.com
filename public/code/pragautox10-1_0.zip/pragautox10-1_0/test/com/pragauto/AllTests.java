package com.pragauto;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class AllTests {

    public static Test suite() {
        TestSuite suite = new TestSuite("All Tests");
        suite.addTestSuite(X10DeviceControllerTest.class);
        suite.addTestSuite(X10DeviceTest.class);
        suite.addTestSuite(X10PublisherTest.class);
        return suite;
    }
    
    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }
}
