package com.pragauto;

import com.pragauto.X10DeviceController;

import junit.framework.TestCase;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10DeviceControllerTest extends TestCase {
    
    private MockX10Device pass;
    private MockX10Device fail;
    
    public void setUp() {
        pass = new MockX10Device("COM1", "A1");
        fail = new MockX10Device("COM1", "A2");  
    }
    
    public void testPass() throws Exception {
        X10DeviceController controller = new X10DeviceController(pass, fail);
        controller.pass();
        assertTrue(true == pass.state);
        assertTrue(false == fail.state);
    }
    
    public void testFail() throws Exception {
        X10DeviceController controller = new X10DeviceController(pass, fail);
        controller.fail();
        assertTrue(false == pass.state);
        assertTrue(true == fail.state);
    }
}
