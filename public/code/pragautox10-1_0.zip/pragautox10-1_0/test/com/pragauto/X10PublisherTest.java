package com.pragauto;

import com.pragauto.X10DeviceController;
import com.pragauto.X10Publisher;

import junit.framework.TestCase;
import net.sourceforge.cruisecontrol.CruiseControlException;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10PublisherTest extends TestCase {
    
    private X10Publisher publisher;
    
    protected void setUp() throws Exception {
        publisher = new X10Publisher();
    }

    protected void tearDown() throws Exception {
        publisher = null;
    }    

    public void testValidate() {
        
        try {
            publisher.validate();
            fail();
        } catch (CruiseControlException expected) {
            assertTrue(true);
        }

        try {
            publisher.setPort("COM1");
            publisher.validate();
            fail();
        } catch (CruiseControlException expected) {
            assertTrue(true);
        }
        
        try {
            publisher.setPort("COM1");
            publisher.setPassDeviceCode("A1");
            publisher.validate();
            fail();
        } catch (CruiseControlException expected) {
            assertTrue(true);
        }
       
        try {
            publisher.setPort("COM1");
            publisher.setPassDeviceCode("A1");
            publisher.setFailDeviceCode("A2");
            publisher.validate();
        } catch (CruiseControlException expected) {
            fail();
        }
        
        X10DeviceController controller = publisher.controller();
        assertNotNull(controller);
        assertEquals("COM1", controller.port());
        assertEquals("A1", controller.passDevice().houseAndUnitCode());
        assertEquals("A2", controller.failDevice().houseAndUnitCode());
    }
}
