package com.pragauto;

import com.pragauto.X10Device;


/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class MockX10Device extends X10Device {
    
    public String portUsed = "";
    public boolean portWasOpened = false;
    public boolean portWasClosed = false;
    public boolean state = false;
    
    public MockX10Device() {
        super();
    }
    
    public MockX10Device(String port, String houseAndUnitCode) {
        super(port, houseAndUnitCode);
    }

    public void openPort() {
        portUsed = port();
        portWasOpened = true;
        portWasClosed = false;
    }
    
    protected void send(boolean state) {
        this.state = state;
    }
    
    public void closePort() {
        portWasClosed = true;  
    }
}
