package com.pragauto;

import javax.comm.*;

import com.micheldalal.x10.CM17A;

/**
 * Any device that speaks X10.
 * 
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10Device {

    private String port;
    private String houseAndUnitCode;
    private CM17A cm17a;
    private SerialPort serialPort;

    private static int DELAY = 500;

    public X10Device() {
        this("COM1", "A1");
    }

    public X10Device(String port, String houseAndUnitCode) {
        this.port = port;
        this.houseAndUnitCode = houseAndUnitCode.toUpperCase();
    }

    public String port() {
        return port;
    }

    public String houseAndUnitCode() {
        return houseAndUnitCode;
    }

    public char houseCode() {
        return houseAndUnitCode.charAt(0);
    }

    public int unitCode() {
        return Integer.parseInt(houseAndUnitCode().substring(1));
    }

    public void on() throws PortInUseException, NoSuchPortException {
        openPort();
        sendOnCommand();
        closePort();
    }

    public void off() throws PortInUseException, NoSuchPortException {
        openPort();
        sendOffCommand();
        closePort();
    }

    protected void sendOnCommand() {
        send(true);
    }

    protected void sendOffCommand() {
        send(false);
    }

    protected void send(boolean state) {
        cm17a = new CM17A(serialPort);
        delay();
        cm17a.setState(houseCode(), unitCode(), state);
    }

    protected void openPort() throws PortInUseException, NoSuchPortException {
        serialPort = (SerialPort) getPortID().open(port(), 2000);
    }

    protected void closePort() throws NoSuchPortException {
        delay();
        serialPort.close();
    }

    protected CommPortIdentifier getPortID() throws NoSuchPortException {
        return CommPortIdentifier.getPortIdentifier(port());
    }

    private void delay() {
        try {
            Thread.sleep(DELAY);
        } catch (InterruptedException ignore) {
        }
    }
}