package com.pragauto;

/**
 * A diagnostic test to verify that two
 * X10 devices are wired up correctly.
 * 
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10Test {

    private static void usage() {
        System.out.println("usage: java " + X10Test.class.getName() + 
            " <port_name> <passDeviceCode> <failDeviceCode");
        System.out.println("  example: COM1 A2 A1");
        System.exit(1);
    }

    public static void main(String[] args) {

        if (args.length < 3) {
            usage();
        }

        String port = args[0];
        String passDeviceCode = args[1];
        String failDeviceCode = args[2];

        X10DeviceController controller = 
          new X10DeviceController(port, passDeviceCode, failDeviceCode);

        try {

            System.out.println("\nTurning pass device (" + passDeviceCode + ") on; " +
                "fail device (" + failDeviceCode + ") off...\n");
            controller.pass();
            
            System.out.println("Pausing 15 seconds for effect...\n");
            try { Thread.sleep(15000); } catch (InterruptedException ignore) {}
            
            System.out.println("Turning pass device (" + passDeviceCode + ") off; " +
                "fail device (" + failDeviceCode + ") on...");
            controller.fail();
            
            System.out.println("\nHave a lot of fun!");

        } catch (X10DeviceException xde) {
            System.err.println("X10 device error: " + xde.getMessage());
        }
    }
}
