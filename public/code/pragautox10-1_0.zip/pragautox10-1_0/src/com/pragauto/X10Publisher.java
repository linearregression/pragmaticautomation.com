package com.pragauto;

import net.sourceforge.cruisecontrol.CruiseControlException;
import net.sourceforge.cruisecontrol.Publisher;
import net.sourceforge.cruisecontrol.util.XMLLogHelper;

import org.apache.log4j.Logger;
import org.jdom.Element;

/**
 * A CruiseControl Publisher plugin for turning on
 * and off X10 devices to indicate the build status.
 * 
 * The CruiseControl config.xml file must include 
 * the following within the <project> element in 
 * order to register the plugin and cause it to be 
 * executed on each build cycle:  
 * 
 *   <plugin name="x10publisher"
 *     classname="com.pragauto.X10Publisher"/>
 *
 *   <publishers>
 *
 *     <x10publisher port="COM1"
 *                   passDeviceCode="A2"
 *                   failDeviceCode="A1" />
 *   </publishers>
 *                   
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10Publisher implements Publisher {

    private static final Logger LOG = Logger.getLogger(X10Publisher.class);
    
    private String port;
    private String failDeviceCode;
    private String passDeviceCode;
    private X10DeviceController controller;
    
    public void setPort(String port) {
        this.port = port;
    }
    
    public String getPort() {
        return port;
    }
    
    public void setFailDeviceCode(String code) {
        failDeviceCode = code;
    }
    
    public String getFailDeviceCode() {
        return failDeviceCode;
    }
    
    public void setPassDeviceCode(String code) {
        passDeviceCode = code;
    }
    
    public String getPassDeviceCode() {
        return passDeviceCode;
    }
    
    public void validate() throws CruiseControlException {
        
        if (getPort() == null) { 
            throw new CruiseControlException("'port' " +
              "not specified in <x10publisher> of configuration file");
        }
        
        if (getPassDeviceCode() == null) { 
            throw new CruiseControlException("'passDeviceCode' " +
              "not specified in <x10publisher> of configuration file");        
        }
        
        if (getFailDeviceCode() == null) { 
            throw new CruiseControlException("'failDeviceCode' " +
              "not specified in <x10publisher> of configuration file");        
        }
        
        controller = new X10DeviceController(getPort(), 
                                             getPassDeviceCode(), 
                                             getFailDeviceCode());
    }
    
    public void publish(Element cruisecontrolLog) 
        throws CruiseControlException {
        
        XMLLogHelper helper = new XMLLogHelper(cruisecontrolLog);
        
        try {
            
            if (helper.isBuildSuccessful()) {
                LOG.info("\nTurning pass device (" + getPassDeviceCode() + 
                    ") on; " + "fail device (" + getFailDeviceCode() + 
                    ") off...\n");
                controller.pass();
            } else {
                LOG.info("\nTurning pass device (" + getPassDeviceCode() + 
                    ") off; " + "fail device (" + getFailDeviceCode() + 
                    ") on...\n");
                controller.fail();
            }
            
        } catch(X10DeviceException xde) {
            LOG.error("X10 device error: " + xde.getMessage());
        }
    }
    
    X10DeviceController controller() {
        return controller;
    }
}
