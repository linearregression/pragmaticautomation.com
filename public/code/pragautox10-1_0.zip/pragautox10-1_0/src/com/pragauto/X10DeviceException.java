package com.pragauto;

/**
 * Thrown when an X10 device has a communication problem.
 * 
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10DeviceException extends Exception {

    public X10DeviceException() {
        super();
    }

    public X10DeviceException(String message) {
        super(message);
    }

    public X10DeviceException(String message, Throwable cause) {
        super(message + " : " + cause.getMessage());
    }
}
