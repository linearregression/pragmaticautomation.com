package com.pragauto;

import javax.comm.NoSuchPortException;
import javax.comm.PortInUseException;

/**
 * Controls two X10 devices: one used to indicate that something was successful
 * and the other that something failed.
 * 
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10DeviceController {

    private String port;
    private X10Device pass;
    private X10Device fail;

    public X10DeviceController(X10Device pass, X10Device fail) {
        port = pass.port();
        this.pass = pass;
        this.fail = fail;
    }

    public X10DeviceController(String port, 
                               String passDeviceCode, 
                               String failDeviceCode) {
        this(new X10Device(port, passDeviceCode), 
             new X10Device(port, failDeviceCode));
    }

    public String port() {
        return port;
    }

    public X10Device passDevice() {
        return pass;
    }

    public X10Device failDevice() {
        return fail;
    }

    /**
     * Turns the fail device off and the pass device on.
     */
    public void pass() throws X10DeviceException {
        try {
            failDevice().off();
            passDevice().on();
        } catch (PortInUseException piux) {
            throw new X10DeviceException(
                "Specified port in use by application: " + piux.currentOwner);
        } catch (NoSuchPortException nspx) {
            throw new X10DeviceException("Specified port not recognized: "
                + port());
        }
    }

    /**
     * Turns the pass device off and the fail device on.
     */
    public void fail() throws X10DeviceException {
        try {
            passDevice().off();
            failDevice().on();
        } catch (PortInUseException piux) {
            throw new X10DeviceException(
                "Specified port in use by application: " + piux.currentOwner);
        } catch (NoSuchPortException nspx) {
            throw new X10DeviceException("Specified port not recognized: "
                + port());
        }
    }
}