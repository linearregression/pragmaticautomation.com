package com.pragprog.auto;

import javax.comm.NoSuchPortException;
import javax.comm.PortInUseException;

import x10.FireCracker;
import x10.X10Command;

/**
 * Any device that speaks X10.
 * 
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10Device {
    
    private String port;
    private String houseAndUnitCode;
    private FireCracker fc;

    public X10Device() {
        this("COM1", "A1");
    }
    
    public X10Device(String port, String houseAndUnitCode) {
        this.port = port;
        this.houseAndUnitCode = houseAndUnitCode.toUpperCase();
        fc = new FireCracker();
    }
    
    public String port() {
        return port;
    }
    
    public String houseAndUnitCode() {
        return houseAndUnitCode;
    }
    
    public char houseCode() {
        return houseAndUnitCode.charAt(0);
    }
    
    public int unitCode() {
        return Integer.parseInt(houseAndUnitCode.substring(1));
    }
    
    public void on() throws PortInUseException, NoSuchPortException {
        openPort();
        sendOnCommand();
        closePort();
    }
    
    public void off() throws PortInUseException, NoSuchPortException {
        openPort();
        sendOffCommand();
        closePort();
    }
    
    protected void sendOnCommand() {
        send(onCommand());
    }
    
    protected void sendOffCommand() {
        send(offCommand());
    }
    
    protected void send(X10Command command) {
        fc.sendCommand(command);  
    }

    protected void openPort() throws PortInUseException, NoSuchPortException {
        fc.openPort(port());
        delay(1000);
    }
    
    protected void closePort() throws PortInUseException, NoSuchPortException {
        fc.closePort();
    }

    protected X10Command onCommand() {
        return X10Command.makeOnCommand(houseCode(), unitCode());
    }
    
    protected X10Command offCommand() {
        return X10Command.makeOffCommand(houseCode(), unitCode());
    }
    
    private void delay(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException ignore) {}
    }
}
