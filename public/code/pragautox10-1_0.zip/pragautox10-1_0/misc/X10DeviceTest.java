package com.pragprog.auto;

import com.pragprog.auto.X10Device;

import junit.framework.TestCase;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class X10DeviceTest extends TestCase {

    public void testMakeOnCommand() {
        X10Device d = new X10Device("COM2", "A1");
        assertEquals("A1_ON", d.onCommand().toString());
    }
    
    public void testMakeOffCommand() {
        X10Device d = new X10Device("COM2", "A2");
        assertEquals("A2_OFF", d.offCommand().toString());
    }
    
    public void testDefaults() {
        X10Device d = new X10Device();
        assertEquals("COM1", d.port());
        assertEquals("A1_ON", d.onCommand().toString());
    }
    
    public void testOn() throws Exception {
        MockX10Device d = new MockX10Device("COM2", "A1");
        d.on();
        assertTrue(d.portWasOpened);
        assertTrue(d.portWasClosed);
        assertEquals("A1_ON", d.commandSent);
        assertEquals("COM2", d.portUsed);
    }
    
    public void testOff() throws Exception {
        MockX10Device d = new MockX10Device("COM2", "A1");
        d.off();
        assertTrue(d.portWasOpened);
        assertTrue(d.portWasClosed);
        assertEquals("A1_OFF", d.commandSent);
        assertEquals("COM2", d.portUsed);
    }
}
