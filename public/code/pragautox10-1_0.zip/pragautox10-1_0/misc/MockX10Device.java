package com.pragprog.auto;

import com.pragprog.auto.X10Device;

import x10.X10Command;

/**
 * @author <b>Mike Clark</b>
 * @author Clarkware Consulting, Inc.
 */

public class MockX10Device extends X10Device {
    
    public String portUsed = "";
    public boolean portWasOpened = false;
    public boolean portWasClosed = false;
    public String commandSent = "";
    
    public MockX10Device() {
        super();
    }
    
    public MockX10Device(String port, String houseAndUnitCode) {
        super(port, houseAndUnitCode);
    }

    public void openPort() {
        portUsed = port();
        portWasOpened = true;
        portWasClosed = false;
    }
    
    protected void send(X10Command command) {
        commandSent = command.toString();
    }
    
    public void closePort() {
        portWasClosed = true;  
    }
}
